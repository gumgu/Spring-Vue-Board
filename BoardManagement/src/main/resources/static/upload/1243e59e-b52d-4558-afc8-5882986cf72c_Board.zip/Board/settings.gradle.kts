rootProject.name = "Board"
